import React, { useState } from 'react';
import {
  REELS_CATEGORIES,
  ReelsCategory,
  generateReelsIdeas,
  ReelIdea,
} from '../data/reelsCaptions';
import { LANGUAGES, Language } from '../data/categories';
import { copyToClipboard, downloadAsTextFile } from '../utils/export';
import {
  Video,
  Sparkles,
  Copy,
  Check,
  Download,
  RotateCcw,
  Music,
  Globe2,
  Flame,
} from 'lucide-react';

interface ReelsCaptionSectionProps {
  onNotify: (msg: string) => void;
}

export const ReelsCaptionSection: React.FC<ReelsCaptionSectionProps> = ({
  onNotify,
}) => {
  const [category, setCategory] = useState<ReelsCategory>('Motivation');
  const [topic, setTopic] = useState('');
  const [language, setLanguage] = useState<Language>('English');
  const [isGenerating, setIsGenerating] = useState(false);
  const [copiedPackageIndex, setCopiedPackageIndex] = useState<number | null>(null);

  const [reelsIdeas, setReelsIdeas] = useState<ReelIdea[]>(() =>
    generateReelsIdeas('Motivation', 'Morning Discipline', 'English')
  );

  const handleGenerate = () => {
    setIsGenerating(true);
    setTimeout(() => {
      const generated = generateReelsIdeas(category, topic, language);
      setReelsIdeas(generated);
      setIsGenerating(false);
      onNotify(`Generated ${category} Reels captions!`);
    }, 200);
  };

  const handleClear = () => {
    setCategory('Motivation');
    setTopic('');
    setLanguage('English');
    setReelsIdeas(generateReelsIdeas('Motivation', 'Morning Discipline', 'English'));
    onNotify('Cleared Reels generator.');
  };

  const handleCopyPackage = async (item: ReelIdea, idx: number) => {
    const text = `${item.hook}\n\n${item.caption}\n\n${item.hashtags.join(' ')}`;
    const ok = await copyToClipboard(text);
    if (ok) {
      setCopiedPackageIndex(idx);
      onNotify('Copied Reel hook, caption, and hashtags!');
      setTimeout(() => setCopiedPackageIndex(null), 1500);
    }
  };

  const handleDownload = () => {
    const content = `VIRALTAGS PRO - INSTAGRAM REELS PACKAGES
Category: ${category}
Topic: ${topic || 'General'}
Language: ${language}
Exported: ${new Date().toLocaleDateString()}

========================================
${reelsIdeas
  .map(
    (item, i) =>
      `REELS IDEA #${i + 1}\nHOOK: ${item.hook}\nCAPTION:\n${item.caption}\nAUDIO SUGGESTION: ${item.audioPrompt}\nHASHTAGS:\n${item.hashtags.join(' ')}\n`
  )
  .join('\n----------------------------------------\n\n')}
`;
    downloadAsTextFile(`reels_${category.toLowerCase()}_${Date.now()}.txt`, content);
    onNotify('Downloaded Reels packages as .txt file!');
  };

  return (
    <section id="reels-captions" className="scroll-mt-24 my-12">
      <div className="glass-panel rounded-3xl p-6 sm:p-10 shadow-2xl relative overflow-hidden">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs font-semibold uppercase tracking-wider mb-2">
              <Video className="w-3.5 h-3.5" />
              <span>Dedicated Short-Video Studio</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Reels Caption &amp; Hook Generator
            </h2>
            <p className="text-sm text-slate-400 mt-1 max-w-xl">
              High-retention 3-second visual hooks, looping captions, trending audio style tips, and paired Reels hashtags.
            </p>
          </div>
        </div>

        {/* Inputs */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-5 mb-8">
          <div className="md:col-span-4">
            <label
              htmlFor="reels-cat"
              className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2 flex items-center gap-1.5"
            >
              <Flame className="w-3.5 h-3.5 text-rose-400" />
              Reels Category ({REELS_CATEGORIES.length})
            </label>
            <div className="relative">
              <select
                id="reels-cat"
                value={category}
                onChange={(e) => setCategory(e.target.value as ReelsCategory)}
                className="w-full px-4 py-3.5 rounded-xl bg-slate-950/80 border border-slate-700/80 focus:border-rose-500 text-white text-sm appearance-none cursor-pointer"
              >
                {REELS_CATEGORIES.map((c) => (
                  <option key={c} value={c} className="bg-slate-900 text-white">
                    {c}
                  </option>
                ))}
              </select>
              <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400 text-xs">
                ▼
              </div>
            </div>
          </div>

          <div className="md:col-span-4">
            <label
              htmlFor="reels-topic"
              className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2"
            >
              Video Topic / Angle
            </label>
            <input
              id="reels-topic"
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="e.g. Street style transition, quick editing speedramp"
              className="w-full px-4 py-3.5 rounded-xl bg-slate-950/80 border border-slate-700/80 focus:border-rose-500 text-white placeholder-slate-500 text-sm transition-all"
            />
          </div>

          <div className="md:col-span-4">
            <label
              htmlFor="reels-lang"
              className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2 flex items-center gap-1.5"
            >
              <Globe2 className="w-3.5 h-3.5 text-purple-400" />
              Language
            </label>
            <div className="relative">
              <select
                id="reels-lang"
                value={language}
                onChange={(e) => setLanguage(e.target.value as Language)}
                className="w-full px-4 py-3.5 rounded-xl bg-slate-950/80 border border-slate-700/80 focus:border-rose-500 text-white text-sm appearance-none cursor-pointer"
              >
                {LANGUAGES.map((l) => (
                  <option key={l.id} value={l.id} className="bg-slate-900 text-white">
                    {l.native}
                  </option>
                ))}
              </select>
              <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400 text-xs">
                ▼
              </div>
            </div>
          </div>
        </div>

        {/* Buttons */}
        <div className="flex flex-wrap items-center gap-3 mb-8">
          <button
            type="button"
            onClick={handleGenerate}
            disabled={isGenerating}
            className="gradient-button flex items-center gap-2 px-6 py-3.5 rounded-xl text-white font-semibold text-sm shadow-lg disabled:opacity-50 cursor-pointer"
          >
            <Sparkles className={`w-4 h-4 ${isGenerating ? 'animate-spin' : ''}`} />
            <span>Generate Reels Packages</span>
          </button>

          <button
            type="button"
            onClick={handleClear}
            className="flex items-center gap-1.5 px-4 py-3.5 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-slate-300 hover:text-white font-medium text-sm transition-colors cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Clear</span>
          </button>

          <button
            type="button"
            onClick={handleDownload}
            className="flex items-center gap-1.5 px-4 py-3.5 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-slate-300 hover:text-white font-medium text-sm transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Download .txt</span>
          </button>
        </div>

        {/* Reels Ideas List */}
        <div className="space-y-5">
          {reelsIdeas.map((item, idx) => (
            <div
              key={idx}
              className="p-5 sm:p-6 rounded-2xl bg-slate-950/70 border border-slate-800/90 hover:border-rose-500/40 transition-all flex flex-col md:flex-row md:items-start justify-between gap-5"
            >
              <div className="space-y-3 flex-1">
                <div className="flex items-center gap-2.5">
                  <span className="text-xs font-mono px-2 py-0.5 rounded bg-rose-950/60 border border-rose-800/50 text-rose-300 font-semibold">
                    Idea #{idx + 1}
                  </span>
                  <div className="flex items-center gap-1 text-xs text-slate-400">
                    <Music className="w-3.5 h-3.5 text-pink-400" />
                    <span>{item.audioPrompt}</span>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-sm font-semibold text-white">
                  {item.hook}
                </div>

                <p className="text-sm text-slate-300 leading-relaxed whitespace-pre-line">
                  {item.caption}
                </p>

                <div className="flex flex-wrap gap-1.5 pt-1">
                  {item.hashtags.map((h) => (
                    <span
                      key={h}
                      className="text-xs text-rose-300 bg-rose-950/30 px-2 py-0.5 rounded border border-rose-900/40"
                    >
                      {h}
                    </span>
                  ))}
                </div>
              </div>

              <div className="shrink-0 flex md:flex-col justify-end gap-2 pt-2 md:pt-0">
                <button
                  type="button"
                  onClick={() => handleCopyPackage(item, idx)}
                  className="flex items-center justify-center gap-1.5 text-xs px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-slate-200 hover:text-rose-300 hover:border-rose-500/50 transition-all cursor-pointer whitespace-nowrap"
                >
                  {copiedPackageIndex === idx ? (
                    <>
                      <Check className="w-4 h-4 text-emerald-400" />
                      <span className="text-emerald-400 font-medium">Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4" />
                      <span>Copy Package</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
