import React from 'react';
import { X, Sparkles, ShieldCheck, HeartHandshake, HelpCircle } from 'lucide-react';

interface AboutModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AboutModal: React.FC<AboutModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div
        className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto bg-slate-900 border border-slate-700/80 rounded-2xl p-6 sm:p-8 text-slate-200 shadow-2xl"
        role="dialog"
        aria-labelledby="about-title"
      >
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-purple-600 to-pink-500 flex items-center justify-center shadow-lg">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 id="about-title" className="text-2xl font-bold text-white tracking-tight">
              About ViralTags Pro
            </h2>
            <p className="text-xs text-purple-400">
              Create Better Content. Discover Better Hashtags.
            </p>
          </div>
        </div>

        <div className="space-y-6 text-sm text-slate-300 leading-relaxed">
          <p>
            <strong className="text-white">ViralTags Pro</strong> is an open, high-performance toolkit created for Instagram creators, social media managers, photographers, and small businesses looking to craft engaging captions, discover categorized hashtags, build memorable bios, and optimize post descriptions.
          </p>

          <div className="p-4 rounded-xl bg-purple-950/30 border border-purple-800/40 text-purple-200">
            <h3 className="font-semibold text-white flex items-center gap-2 mb-1.5">
              <ShieldCheck className="w-4 h-4 text-pink-400" />
              Our Algorithmic Honesty Pledge
            </h3>
            <p className="text-xs text-purple-200/90 leading-relaxed">
              We never promise guaranteed viral fame. In reality, Instagram’s recommendation algorithm evaluates viewer watch time, saves, shares, and semantic post context. Hashtags and SEO keywords serve to categorize your content accurately so the system can deliver it to viewers genuinely interested in your niche.
            </p>
          </div>

          <div>
            <h3 className="text-base font-semibold text-white mb-2 flex items-center gap-2">
              <HeartHandshake className="w-4 h-4 text-purple-400" />
              Multilingual Inclusivity
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Content creation thrives in regional voices. ViralTags Pro natively supports <strong className="text-white">English</strong>, <strong className="text-white">Hindi (हिन्दी)</strong>, and <strong className="text-white">Assamese (অসমীয়া)</strong>, empowering creators across diverse linguistic communities to express themselves authentically.
            </p>
          </div>

          <div>
            <h3 className="text-base font-semibold text-white mb-2 flex items-center gap-2">
              <HelpCircle className="w-4 h-4 text-pink-400" />
              Key Features
            </h3>
            <ul className="list-disc pl-5 space-y-1 text-xs text-slate-300">
              <li>Hashtag generator categorized by reach tier and content format.</li>
              <li>10 creative caption ideas tailored across 8 emotional tones.</li>
              <li>Full description writer with customizable Call-To-Action (CTA) hooks.</li>
              <li>Keyword and SEO search tag suggestions for Instagram explore search.</li>
              <li>Bio generator with live 150-character limit counter.</li>
              <li>Reels hook and caption ideas with paired trending tags.</li>
            </ul>
          </div>
        </div>

        <div className="mt-8 pt-4 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 text-white font-medium text-sm hover:opacity-95 transition-opacity"
          >
            Got it, Let's Create
          </button>
        </div>
      </div>
    </div>
  );
};
