import React, { useState } from 'react';
import {
  DescriptionLength,
  CTA_OPTIONS,
  generatePostDescription,
  GeneratedDescription,
} from '../data/descriptions';
import { LANGUAGES, Language } from '../data/categories';
import { copyToClipboard, downloadAsTextFile } from '../utils/export';
import {
  FileText,
  Sparkles,
  Copy,
  Check,
  Download,
  RotateCcw,
  Sliders,
  Globe2,
  Bookmark,
} from 'lucide-react';

interface DescriptionGeneratorSectionProps {
  onNotify: (msg: string) => void;
}

export const DescriptionGeneratorSection: React.FC<DescriptionGeneratorSectionProps> = ({
  onNotify,
}) => {
  const [topic, setTopic] = useState('');
  const [length, setLength] = useState<DescriptionLength>('Medium');
  const [language, setLanguage] = useState<Language>('English');
  const [selectedCta, setSelectedCta] = useState<string>('save');
  const [isGenerating, setIsGenerating] = useState(false);
  const [copiedPart, setCopiedPart] = useState<string | null>(null);

  const [description, setDescription] = useState<GeneratedDescription>(() =>
    generatePostDescription('Consistency in Photography', 'Medium', 'English', 'save')
  );

  const handleGenerate = () => {
    setIsGenerating(true);
    setTimeout(() => {
      const generated = generatePostDescription(topic, length, language, selectedCta);
      setDescription(generated);
      setIsGenerating(false);
      onNotify('Generated post description!');
    }, 250);
  };

  const handleClear = () => {
    setTopic('');
    setLength('Medium');
    setLanguage('English');
    setSelectedCta('save');
    setDescription(
      generatePostDescription('Consistency in Photography', 'Medium', 'English', 'save')
    );
    onNotify('Cleared description inputs.');
  };

  const handleCopyFull = async () => {
    const ok = await copyToClipboard(description.fullText);
    if (ok) {
      setCopiedPart('full');
      onNotify('Copied entire description to clipboard!');
      setTimeout(() => setCopiedPart(null), 1500);
    }
  };

  const handleCopyCta = async () => {
    const ok = await copyToClipboard(description.cta);
    if (ok) {
      setCopiedPart('cta');
      onNotify('Copied call-to-action line!');
      setTimeout(() => setCopiedPart(null), 1500);
    }
  };

  const handleDownload = () => {
    const content = `VIRALTAGS PRO - INSTAGRAM POST DESCRIPTION
Topic: ${topic || 'General Topic'}
Length: ${length}
Language: ${language}
Exported: ${new Date().toLocaleDateString()}

========================================
FULL DESCRIPTION:
${description.fullText}

========================================
HEADLINE:
${description.headline}

BODY PROSE:
${description.body}

CALL TO ACTION:
${description.cta}

SUGGESTED TAGS:
${description.suggestedTags.join(' ')}
`;
    downloadAsTextFile(`description_${length.toLowerCase()}_${Date.now()}.txt`, content);
    onNotify('Downloaded post description as .txt file!');
  };

  return (
    <section id="description-generator" className="scroll-mt-24 my-12">
      <div className="glass-panel rounded-3xl p-6 sm:p-10 shadow-2xl relative overflow-hidden">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-xs font-semibold uppercase tracking-wider mb-2">
              <FileText className="w-3.5 h-3.5" />
              <span>Full Post Copywriter</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Instagram Description Generator
            </h2>
            <p className="text-sm text-slate-400 mt-1 max-w-xl">
              Write structured, high-value post descriptions with attention-grabbing hooks, body storytelling, and call-to-action selections.
            </p>
          </div>
        </div>

        {/* Inputs */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-5 mb-8">
          {/* Topic */}
          <div className="md:col-span-12">
            <label
              htmlFor="desc-topic"
              className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2"
            >
              Post Topic / Main Value <span className="text-pink-400">*</span>
            </label>
            <input
              id="desc-topic"
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="e.g. 5 photography mistakes I made as a beginner, How to plan a weekend trip"
              className="w-full px-4 py-3.5 rounded-xl bg-slate-950/80 border border-slate-700/80 focus:border-indigo-500 text-white placeholder-slate-500 text-sm transition-all"
            />
          </div>

          {/* Length */}
          <div className="md:col-span-4">
            <label
              htmlFor="desc-length"
              className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2 flex items-center gap-1.5"
            >
              <Sliders className="w-3.5 h-3.5 text-indigo-400" />
              Length
            </label>
            <div className="relative">
              <select
                id="desc-length"
                value={length}
                onChange={(e) => setLength(e.target.value as DescriptionLength)}
                className="w-full px-4 py-3.5 rounded-xl bg-slate-950/80 border border-slate-700/80 focus:border-indigo-500 text-white text-sm appearance-none cursor-pointer"
              >
                <option value="Short">Short (Quick Take, ~150 words)</option>
                <option value="Medium">Medium (3 Action Rules, ~300 words)</option>
                <option value="Long">Long (Deep Dive Guide, ~500 words)</option>
              </select>
              <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400 text-xs">
                ▼
              </div>
            </div>
          </div>

          {/* Language */}
          <div className="md:col-span-4">
            <label
              htmlFor="desc-lang"
              className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2 flex items-center gap-1.5"
            >
              <Globe2 className="w-3.5 h-3.5 text-purple-400" />
              Language
            </label>
            <div className="relative">
              <select
                id="desc-lang"
                value={language}
                onChange={(e) => setLanguage(e.target.value as Language)}
                className="w-full px-4 py-3.5 rounded-xl bg-slate-950/80 border border-slate-700/80 focus:border-indigo-500 text-white text-sm appearance-none cursor-pointer"
              >
                {LANGUAGES.map((lang) => (
                  <option key={lang.id} value={lang.id} className="bg-slate-900 text-white">
                    {lang.native}
                  </option>
                ))}
              </select>
              <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400 text-xs">
                ▼
              </div>
            </div>
          </div>

          {/* Call-to-action suggestion */}
          <div className="md:col-span-4">
            <label
              htmlFor="desc-cta"
              className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2 flex items-center gap-1.5"
            >
              <Bookmark className="w-3.5 h-3.5 text-pink-400" />
              Call-To-Action (CTA) Hook
            </label>
            <div className="relative">
              <select
                id="desc-cta"
                value={selectedCta}
                onChange={(e) => setSelectedCta(e.target.value)}
                className="w-full px-4 py-3.5 rounded-xl bg-slate-950/80 border border-slate-700/80 focus:border-indigo-500 text-white text-sm appearance-none cursor-pointer"
              >
                {CTA_OPTIONS.map((cta) => (
                  <option key={cta.id} value={cta.id} className="bg-slate-900 text-white">
                    {cta.label}
                  </option>
                ))}
              </select>
              <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400 text-xs">
                ▼
              </div>
            </div>
          </div>
        </div>

        {/* Buttons */}
        <div className="flex flex-wrap items-center gap-3 mb-8">
          <button
            type="button"
            onClick={handleGenerate}
            disabled={isGenerating}
            className="gradient-button flex items-center gap-2 px-6 py-3.5 rounded-xl text-white font-semibold text-sm shadow-lg disabled:opacity-50 cursor-pointer"
          >
            <Sparkles className={`w-4 h-4 ${isGenerating ? 'animate-spin' : ''}`} />
            <span>Generate Description</span>
          </button>

          <button
            type="button"
            onClick={handleClear}
            className="flex items-center gap-1.5 px-4 py-3.5 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-slate-300 hover:text-white font-medium text-sm transition-colors cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Clear</span>
          </button>

          <button
            type="button"
            onClick={handleCopyFull}
            className="flex items-center gap-1.5 px-4 py-3.5 rounded-xl bg-indigo-600/20 border border-indigo-500/40 hover:bg-indigo-600/30 text-indigo-300 hover:text-white font-medium text-sm transition-colors cursor-pointer"
          >
            {copiedPart === 'full' ? (
              <Check className="w-4 h-4 text-emerald-400" />
            ) : (
              <Copy className="w-4 h-4" />
            )}
            <span>Copy Full Description</span>
          </button>

          <button
            type="button"
            onClick={handleDownload}
            className="flex items-center gap-1.5 px-4 py-3.5 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-slate-300 hover:text-white font-medium text-sm transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Download .txt</span>
          </button>
        </div>

        {/* Formatted Output Preview */}
        <div className="p-6 rounded-2xl bg-slate-950/80 border border-slate-800/90 space-y-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <span className="text-xs font-mono text-indigo-400 font-semibold uppercase">
              Formatted Preview ({length} Format)
            </span>
            <span className="text-xs text-slate-400">
              Ready to paste directly into Instagram
            </span>
          </div>

          <div>
            <h4 className="text-sm font-bold text-white mb-2">
              {description.headline}
            </h4>
            <p className="text-sm text-slate-300 leading-relaxed whitespace-pre-line">
              {description.body}
            </p>
          </div>

          <div className="pt-2 flex items-center justify-between p-3.5 rounded-xl bg-indigo-950/20 border border-indigo-900/30">
            <span className="text-sm text-indigo-200 font-medium">
              {description.cta}
            </span>
            <button
              type="button"
              onClick={handleCopyCta}
              className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1 ml-3 shrink-0"
            >
              {copiedPart === 'cta' ? (
                <Check className="w-3.5 h-3.5 text-emerald-400" />
              ) : (
                <Copy className="w-3.5 h-3.5" />
              )}
              <span>Copy CTA</span>
            </button>
          </div>

          <div className="flex flex-wrap gap-1.5 pt-2">
            {description.suggestedTags.map((t) => (
              <span
                key={t}
                className="text-xs text-purple-400 bg-purple-950/40 px-2 py-0.5 rounded border border-purple-900/50"
              >
                {t}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
