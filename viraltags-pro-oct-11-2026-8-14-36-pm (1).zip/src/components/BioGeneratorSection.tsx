import React, { useState } from 'react';
import {
  CATEGORIES,
  CategoryKey,
} from '../data/categories';
import {
  BIO_STYLES,
  BioStyle,
  BioIdea,
  generateBioIdeas,
} from '../data/bios';
import { copyToClipboard, downloadAsTextFile } from '../utils/export';
import {
  UserCheck,
  Sparkles,
  Copy,
  Check,
  Download,
  RotateCcw,
  Smile,
  AlertCircle,
} from 'lucide-react';

interface BioGeneratorSectionProps {
  onNotify: (msg: string) => void;
}

export const BioGeneratorSection: React.FC<BioGeneratorSectionProps> = ({
  onNotify,
}) => {
  const [brandName, setBrandName] = useState('');
  const [category, setCategory] = useState<CategoryKey>('Travel');
  const [style, setStyle] = useState<BioStyle>('Aesthetic & Clean');
  const [includeEmojis, setIncludeEmojis] = useState(true);
  const [isGenerating, setIsGenerating] = useState(false);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const [bios, setBios] = useState<BioIdea[]>(() =>
    generateBioIdeas('Elena Vance', 'Travel', 'Aesthetic & Clean', true)
  );

  const handleGenerate = () => {
    setIsGenerating(true);
    setTimeout(() => {
      const generated = generateBioIdeas(brandName, category, style, includeEmojis);
      setBios(generated);
      setIsGenerating(false);
      onNotify('Generated aesthetic bio ideas!');
    }, 200);
  };

  const handleClear = () => {
    setBrandName('');
    setCategory('Travel');
    setStyle('Aesthetic & Clean');
    setIncludeEmojis(true);
    setBios(generateBioIdeas('Elena Vance', 'Travel', 'Aesthetic & Clean', true));
    onNotify('Cleared bio generator.');
  };

  const handleCopy = async (text: string, idx: number) => {
    const ok = await copyToClipboard(text);
    if (ok) {
      setCopiedIndex(idx);
      onNotify('Bio copied to clipboard!');
      setTimeout(() => setCopiedIndex(null), 1500);
    }
  };

  const handleDownload = () => {
    const content = `VIRALTAGS PRO - INSTAGRAM BIO IDEAS
Brand Name: ${brandName || 'Creator'}
Category: ${category}
Style: ${style}
Emojis: ${includeEmojis ? 'Enabled' : 'Disabled'}
Exported: ${new Date().toLocaleDateString()}

========================================
${bios.map((b, i) => `IDEA ${i + 1} (${b.charCount}/150 chars):\n${b.text}\n`).join('\n------------------------\n\n')}
`;
    downloadAsTextFile(`bios_${category.toLowerCase()}_${Date.now()}.txt`, content);
    onNotify('Downloaded bio ideas as .txt file!');
  };

  return (
    <section id="bio-generator" className="scroll-mt-24 my-12">
      <div className="glass-panel rounded-3xl p-6 sm:p-10 shadow-2xl relative overflow-hidden">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs font-semibold uppercase tracking-wider mb-2">
              <UserCheck className="w-3.5 h-3.5" />
              <span>Profile Optimizer</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Instagram Bio Generator
            </h2>
            <p className="text-sm text-slate-400 mt-1 max-w-xl">
              Turn your profile into a high-converting landing page with formatted bios and real-time 150-character limit tracking.
            </p>
          </div>
        </div>

        {/* Inputs */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-5 mb-8">
          <div className="md:col-span-4">
            <label
              htmlFor="bio-name"
              className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2"
            >
              Name or Brand Username
            </label>
            <input
              id="bio-name"
              type="text"
              value={brandName}
              onChange={(e) => setBrandName(e.target.value)}
              placeholder="e.g. Maya Lin or @mayalin"
              className="w-full px-4 py-3.5 rounded-xl bg-slate-950/80 border border-slate-700/80 focus:border-emerald-500 text-white placeholder-slate-500 text-sm transition-all"
            />
          </div>

          <div className="md:col-span-3">
            <label
              htmlFor="bio-cat"
              className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2"
            >
              Category
            </label>
            <div className="relative">
              <select
                id="bio-cat"
                value={category}
                onChange={(e) => setCategory(e.target.value as CategoryKey)}
                className="w-full px-4 py-3.5 rounded-xl bg-slate-950/80 border border-slate-700/80 focus:border-emerald-500 text-white text-sm appearance-none cursor-pointer"
              >
                {CATEGORIES.map((c) => (
                  <option key={c} value={c} className="bg-slate-900 text-white">
                    {c}
                  </option>
                ))}
              </select>
              <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400 text-xs">
                ▼
              </div>
            </div>
          </div>

          <div className="md:col-span-3">
            <label
              htmlFor="bio-style"
              className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2"
            >
              Bio Style
            </label>
            <div className="relative">
              <select
                id="bio-style"
                value={style}
                onChange={(e) => setStyle(e.target.value as BioStyle)}
                className="w-full px-4 py-3.5 rounded-xl bg-slate-950/80 border border-slate-700/80 focus:border-emerald-500 text-white text-sm appearance-none cursor-pointer"
              >
                {BIO_STYLES.map((s) => (
                  <option key={s} value={s} className="bg-slate-900 text-white">
                    {s}
                  </option>
                ))}
              </select>
              <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400 text-xs">
                ▼
              </div>
            </div>
          </div>

          {/* Emoji Toggle */}
          <div className="md:col-span-2 flex flex-col justify-end">
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Emojis
            </label>
            <button
              type="button"
              onClick={() => setIncludeEmojis(!includeEmojis)}
              className={`w-full py-3 px-3 rounded-xl border text-xs font-medium flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                includeEmojis
                  ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-300'
                  : 'bg-slate-950 border-slate-700 text-slate-400'
              }`}
            >
              <Smile className="w-3.5 h-3.5" />
              <span>{includeEmojis ? 'With Emojis' : 'Clean Text'}</span>
            </button>
          </div>
        </div>

        {/* Buttons */}
        <div className="flex flex-wrap items-center gap-3 mb-8">
          <button
            type="button"
            onClick={handleGenerate}
            disabled={isGenerating}
            className="gradient-button flex items-center gap-2 px-6 py-3.5 rounded-xl text-white font-semibold text-sm shadow-lg disabled:opacity-50 cursor-pointer"
          >
            <Sparkles className={`w-4 h-4 ${isGenerating ? 'animate-spin' : ''}`} />
            <span>Generate Stylish Bios</span>
          </button>

          <button
            type="button"
            onClick={handleClear}
            className="flex items-center gap-1.5 px-4 py-3.5 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-slate-300 hover:text-white font-medium text-sm transition-colors cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Clear</span>
          </button>

          <button
            type="button"
            onClick={handleDownload}
            className="flex items-center gap-1.5 px-4 py-3.5 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-slate-300 hover:text-white font-medium text-sm transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Download .txt</span>
          </button>
        </div>

        {/* Bio Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {bios.map((bio, idx) => {
            const isOverLimit = bio.charCount > 150;
            return (
              <div
                key={idx}
                className="p-5 rounded-2xl bg-slate-950/70 border border-slate-800/90 hover:border-emerald-500/40 transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800/70">
                    <span className="text-xs font-mono text-emerald-400 font-semibold">
                      Option {idx + 1}
                    </span>

                    {/* 150-char length indicator */}
                    <div className="flex items-center gap-1.5">
                      {isOverLimit && (
                        <AlertCircle className="w-3.5 h-3.5 text-rose-400" />
                      )}
                      <span
                        className={`text-xs font-mono font-medium ${
                          isOverLimit
                            ? 'text-rose-400'
                            : bio.charCount > 130
                            ? 'text-amber-400'
                            : 'text-slate-400'
                        }`}
                      >
                        {bio.charCount} / 150 chars
                      </span>
                    </div>
                  </div>

                  <p className="text-sm text-slate-200 whitespace-pre-line leading-relaxed mb-4">
                    {bio.text}
                  </p>
                </div>

                <div className="pt-2 flex justify-end">
                  <button
                    type="button"
                    onClick={() => handleCopy(bio.text, idx)}
                    className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-slate-300 hover:text-emerald-300 hover:border-emerald-500/50 transition-all cursor-pointer"
                  >
                    {copiedIndex === idx ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400 font-medium">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy Bio</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
