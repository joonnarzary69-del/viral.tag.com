import React from 'react';
import { X, Lock, CheckCircle, EyeOff, Shield } from 'lucide-react';

interface PrivacyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PrivacyModal: React.FC<PrivacyModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div
        className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto bg-slate-900 border border-slate-700/80 rounded-2xl p-6 sm:p-8 text-slate-200 shadow-2xl"
        role="dialog"
        aria-labelledby="privacy-title"
      >
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-purple-600 to-pink-500 flex items-center justify-center shadow-lg">
            <Lock className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 id="privacy-title" className="text-2xl font-bold text-white tracking-tight">
              Privacy Policy
            </h2>
            <p className="text-xs text-purple-400">Last updated: October 2026</p>
          </div>
        </div>

        <div className="space-y-5 text-xs sm:text-sm text-slate-300 leading-relaxed">
          <div className="p-3.5 rounded-xl bg-emerald-950/30 border border-emerald-800/40 text-emerald-200 flex items-start gap-2.5">
            <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-white text-xs sm:text-sm mb-0.5">
                Zero Password &amp; Zero Account Policy
              </p>
              <p className="text-xs text-emerald-200/90">
                ViralTags Pro will <strong>NEVER</strong> ask for your Instagram password, Meta login credentials, or personal social media tokens. You can use all generators freely without logging in or creating an account.
              </p>
            </div>
          </div>

          <section>
            <h3 className="text-sm font-semibold text-white mb-1.5 flex items-center gap-2">
              <EyeOff className="w-4 h-4 text-purple-400" />
              1. Local and Ephemeral Processing
            </h3>
            <p className="text-slate-300">
              When you enter a post topic, caption theme, or bio details, the processing occurs directly inside your client browser. We do not store, catalog, log, or sell your generated hashtags, captions, or descriptions on any remote database. Once you close or refresh your tab, ephemeral inputs are cleared.
            </p>
          </section>

          <section>
            <h3 className="text-sm font-semibold text-white mb-1.5 flex items-center gap-2">
              <Shield className="w-4 h-4 text-pink-400" />
              2. Cookies &amp; Third-Party Advertising
            </h3>
            <p className="text-slate-300 mb-2">
              ViralTags Pro does not place intrusive tracking cookies. In the future, once official Google AdSense scripts are approved and mounted on designated advertising slots:
            </p>
            <ul className="list-disc pl-5 space-y-1 text-slate-300">
              <li>Google and third-party vendors use cookies to serve ads based on prior visits to this or other websites.</li>
              <li>Users may opt out of personalized advertising by visiting Google Ads Settings (www.google.com/settings/ads).</li>
            </ul>
          </section>

          <section>
            <h3 className="text-sm font-semibold text-white mb-1.5">
              3. Analytics &amp; Performance
            </h3>
            <p className="text-slate-300">
              We do not track individual users across devices. Any hosting performance metrics collected by CDN edge nodes are aggregated and anonymized for uptime monitoring only.
            </p>
          </section>

          <section>
            <h3 className="text-sm font-semibold text-white mb-1.5">
              4. Contact Regarding Privacy
            </h3>
            <p className="text-slate-300">
              If you have any questions or data inquiries regarding this Privacy Policy, please reach out via our interactive Contact modal on this website.
            </p>
          </section>
        </div>

        <div className="mt-8 pt-4 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-medium text-sm transition-colors"
          >
            I Understand
          </button>
        </div>
      </div>
    </div>
  );
};
