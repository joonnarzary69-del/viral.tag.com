import React, { useState } from 'react';
import {
  CATEGORIES,
  CategoryKey,
} from '../data/categories';
import {
  generateKeywordsAndTags,
  KeywordTagResult,
} from '../data/tags';
import { copyToClipboard, downloadAsTextFile } from '../utils/export';
import {
  Tag,
  Sparkles,
  Copy,
  Check,
  Download,
  RotateCcw,
  Search,
  Key,
} from 'lucide-react';

interface TagGeneratorSectionProps {
  onNotify: (msg: string) => void;
}

export const TagGeneratorSection: React.FC<TagGeneratorSectionProps> = ({
  onNotify,
}) => {
  const [topic, setTopic] = useState('');
  const [category, setCategory] = useState<CategoryKey>('Technology');
  const [isGenerating, setIsGenerating] = useState(false);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const [tagData, setTagData] = useState<KeywordTagResult>(() =>
    generateKeywordsAndTags('Artificial Intelligence tools', 'Technology')
  );

  const handleGenerate = () => {
    setIsGenerating(true);
    setTimeout(() => {
      const generated = generateKeywordsAndTags(topic, category);
      setTagData(generated);
      setIsGenerating(false);
      onNotify('Generated keyword and search tags!');
    }, 200);
  };

  const handleClear = () => {
    setTopic('');
    setCategory('Technology');
    setTagData(generateKeywordsAndTags('Artificial Intelligence tools', 'Technology'));
    onNotify('Cleared tag generator.');
  };

  const handleCopySingleKeyword = async (kw: string) => {
    const ok = await copyToClipboard(kw);
    if (ok) {
      setCopiedKey(kw);
      onNotify(`Copied "${kw}"`);
      setTimeout(() => setCopiedKey(null), 1500);
    }
  };

  const handleCopyCommaSeparated = async () => {
    const ok = await copyToClipboard(tagData.commaSeparatedTags);
    if (ok) {
      setCopiedKey('comma');
      onNotify('Copied all search keywords (comma-separated)!');
      setTimeout(() => setCopiedKey(null), 1500);
    }
  };

  const handleCopyHashtags = async () => {
    const ok = await copyToClipboard(tagData.hashtagBundle);
    if (ok) {
      setCopiedKey('hash');
      onNotify('Copied keyword hashtag bundle!');
      setTimeout(() => setCopiedKey(null), 1500);
    }
  };

  const handleDownload = () => {
    const content = `VIRALTAGS PRO - INSTAGRAM SEARCH KEYWORDS & TAGS
Topic: ${topic || 'General Topic'}
Category: ${category}
Export Date: ${new Date().toLocaleDateString()}

========================================
PRIMARY SEARCH KEYWORDS:
${tagData.primaryKeywords.map((k) => `• ${k}`).join('\n')}

========================================
SECONDARY NICHE PHRASES:
${tagData.secondaryKeywords.map((k) => `• ${k}`).join('\n')}

========================================
COMMA-SEPARATED (FOR SEO & ALT TEXT):
${tagData.commaSeparatedTags}

========================================
TAG BUNDLE:
${tagData.hashtagBundle}
`;
    downloadAsTextFile(`tags_${category.toLowerCase()}_${Date.now()}.txt`, content);
    onNotify('Downloaded tags as .txt file!');
  };

  return (
    <section id="tag-generator" className="scroll-mt-24 my-12">
      <div className="glass-panel rounded-3xl p-6 sm:p-10 shadow-2xl relative overflow-hidden">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-300 text-xs font-semibold uppercase tracking-wider mb-2">
              <Tag className="w-3.5 h-3.5" />
              <span>SEO &amp; Search Indexing</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Instagram Tag &amp; Keyword Generator
            </h2>
            <p className="text-sm text-slate-400 mt-1 max-w-xl">
              Extract high-intent search keywords and phrase tags that help Instagram index your post in the Explore search bar.
            </p>
          </div>
        </div>

        {/* Inputs */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-5 mb-8">
          <div className="md:col-span-8">
            <label
              htmlFor="tag-topic"
              className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2"
            >
              Topic / Niche Focus <span className="text-pink-400">*</span>
            </label>
            <input
              id="tag-topic"
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="e.g. Graphic design portfolio tips, healthy airfryer recipes"
              className="w-full px-4 py-3.5 rounded-xl bg-slate-950/80 border border-slate-700/80 focus:border-cyan-500 text-white placeholder-slate-500 text-sm transition-all"
            />
          </div>

          <div className="md:col-span-4">
            <label
              htmlFor="tag-cat"
              className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2"
            >
              Category
            </label>
            <div className="relative">
              <select
                id="tag-cat"
                value={category}
                onChange={(e) => setCategory(e.target.value as CategoryKey)}
                className="w-full px-4 py-3.5 rounded-xl bg-slate-950/80 border border-slate-700/80 focus:border-cyan-500 text-white text-sm appearance-none cursor-pointer"
              >
                {CATEGORIES.map((c) => (
                  <option key={c} value={c} className="bg-slate-900 text-white">
                    {c}
                  </option>
                ))}
              </select>
              <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400 text-xs">
                ▼
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-3 mb-8">
          <button
            type="button"
            onClick={handleGenerate}
            disabled={isGenerating}
            className="gradient-button flex items-center gap-2 px-6 py-3.5 rounded-xl text-white font-semibold text-sm shadow-lg disabled:opacity-50 cursor-pointer"
          >
            <Sparkles className={`w-4 h-4 ${isGenerating ? 'animate-spin' : ''}`} />
            <span>Generate Keywords &amp; Tags</span>
          </button>

          <button
            type="button"
            onClick={handleClear}
            className="flex items-center gap-1.5 px-4 py-3.5 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-slate-300 hover:text-white font-medium text-sm transition-colors cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Clear</span>
          </button>

          <button
            type="button"
            onClick={handleCopyCommaSeparated}
            className="flex items-center gap-1.5 px-4 py-3.5 rounded-xl bg-cyan-600/20 border border-cyan-500/40 hover:bg-cyan-600/30 text-cyan-300 hover:text-white font-medium text-sm transition-colors cursor-pointer"
          >
            {copiedKey === 'comma' ? (
              <Check className="w-4 h-4 text-emerald-400" />
            ) : (
              <Copy className="w-4 h-4" />
            )}
            <span>Copy All Keywords (Comma-Separated)</span>
          </button>

          <button
            type="button"
            onClick={handleCopyHashtags}
            className="flex items-center gap-1.5 px-4 py-3.5 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-slate-300 hover:text-white font-medium text-sm transition-colors cursor-pointer"
          >
            {copiedKey === 'hash' ? (
              <Check className="w-4 h-4 text-emerald-400" />
            ) : (
              <Copy className="w-4 h-4" />
            )}
            <span>Copy Tag Bundle</span>
          </button>

          <button
            type="button"
            onClick={handleDownload}
            className="flex items-center gap-1.5 px-4 py-3.5 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-slate-300 hover:text-white font-medium text-sm transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Download .txt</span>
          </button>
        </div>

        {/* Results */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Primary Keywords */}
          <div className="p-5 rounded-2xl bg-slate-950/70 border border-slate-800/90">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Search className="w-4 h-4 text-cyan-400" />
                <h3 className="text-sm font-semibold text-white">
                  Primary Search Keywords ({tagData.primaryKeywords.length})
                </h3>
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              {tagData.primaryKeywords.map((kw) => (
                <button
                  key={kw}
                  type="button"
                  onClick={() => handleCopySingleKeyword(kw)}
                  className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 hover:border-cyan-500/60 text-xs text-cyan-200 hover:text-white transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <span>{kw}</span>
                  {copiedKey === kw ? (
                    <Check className="w-3 h-3 text-emerald-400" />
                  ) : (
                    <Copy className="w-3 h-3 text-slate-500 opacity-60" />
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Secondary Keywords */}
          <div className="p-5 rounded-2xl bg-slate-950/70 border border-slate-800/90">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Key className="w-4 h-4 text-purple-400" />
                <h3 className="text-sm font-semibold text-white">
                  Secondary Niche Phrases ({tagData.secondaryKeywords.length})
                </h3>
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              {tagData.secondaryKeywords.map((kw) => (
                <button
                  key={kw}
                  type="button"
                  onClick={() => handleCopySingleKeyword(kw)}
                  className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 hover:border-purple-500/60 text-xs text-purple-200 hover:text-white transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <span>{kw}</span>
                  {copiedKey === kw ? (
                    <Check className="w-3 h-3 text-emerald-400" />
                  ) : (
                    <Copy className="w-3 h-3 text-slate-500 opacity-60" />
                  )}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
