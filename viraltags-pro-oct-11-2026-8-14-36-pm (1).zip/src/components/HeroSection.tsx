import React from 'react';
import { Sparkles, ArrowRight, Hash, MessageSquare, Video, UserCheck, ShieldCheck } from 'lucide-react';

interface HeroSectionProps {
  onScrollTo: (id: string) => void;
  onOpenAbout: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onScrollTo,
  onOpenAbout,
}) => {
  return (
    <section className="relative pt-8 sm:pt-14 pb-12 sm:pb-20 overflow-hidden">
      {/* Background radial gradient accent */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-purple-600/15 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          {/* Left Column: Value Proposition & Copy */}
          <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-900 border border-slate-700/80 text-xs text-purple-300 font-medium">
              <Sparkles className="w-3.5 h-3.5 text-pink-400" />
              <span>Free Instagram Creator Toolkit · English, Hindi &amp; Assamese</span>
            </div>

            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold text-white tracking-tight text-balance leading-[1.12]">
              Create Better Content.{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-400 to-rose-400">
                Discover Better Hashtags.
              </span>
            </h1>

            <p className="text-base sm:text-lg text-slate-300 max-w-2xl mx-auto lg:mx-0 leading-relaxed">
              ViralTags Pro generates high-relevance hashtags, engaging caption hooks, structured descriptions, SEO keyword tags, and aesthetic bios for Instagram creators and Reels.
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-4 pt-2">
              <button
                type="button"
                onClick={() => onScrollTo('hashtag-generator')}
                className="gradient-button flex items-center gap-2 px-7 py-4 rounded-xl text-white font-semibold text-sm sm:text-base shadow-xl shadow-purple-950/50 cursor-pointer"
              >
                <span>Generate Now</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={onOpenAbout}
                className="px-5 py-4 rounded-xl bg-slate-900/90 border border-slate-700/80 hover:border-purple-500/50 text-slate-200 hover:text-white text-sm sm:text-base font-medium transition-colors cursor-pointer"
              >
                How It Works
              </button>
            </div>

            {/* Feature trust markers */}
            <div className="pt-4 flex flex-wrap items-center justify-center lg:justify-start gap-6 text-xs text-slate-400">
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>100% Free · No Password Required</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-purple-400" />
                <span>13 Curated Categories</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-pink-400" />
                <span>1-Click Copy &amp; Download</span>
              </div>
            </div>
          </div>

          {/* Right Column: Visual Showcase Media Frame */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-3xl overflow-hidden border border-slate-700/70 shadow-2xl bg-slate-900 aspect-[16/10] lg:aspect-auto lg:h-[460px] group">
              <img
                src="/src/assets/images/hero_creator_workspace_1791728919640.jpg"
                alt="ViralTags Pro modern creator workspace and Instagram reels recording setup"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                onError={(e) => {
                  // Fallback container in case asset load is interrupted
                  const target = e.target as HTMLElement;
                  target.style.display = 'none';
                  if (target.parentElement) {
                    target.parentElement.classList.add('bg-gradient-to-tr', 'from-purple-950', 'via-slate-900', 'to-slate-950');
                  }
                }}
              />

              {/* Scrim Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-transparent pointer-events-none" />

              {/* Float badge */}
              <div className="absolute bottom-5 left-5 right-5 p-4 rounded-2xl bg-slate-950/80 backdrop-blur-md border border-white/10 text-xs">
                <div className="flex items-center justify-between text-white font-semibold mb-1">
                  <span>ViralTags Pro Studio</span>
                  <span className="text-[11px] text-pink-400">Multi-Format Ready</span>
                </div>
                <p className="text-slate-300 text-[11px] leading-relaxed">
                  Tailored for Reels, photo dumps, carousels, and creator bios.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Quick jump bar */}
        <div className="mt-12 pt-6 border-t border-slate-800/80">
          <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3 text-center lg:text-left">
            Jump Directly to Tool:
          </p>
          <div className="flex flex-wrap items-center justify-center lg:justify-start gap-2 sm:gap-3">
            <button
              type="button"
              onClick={() => onScrollTo('hashtag-generator')}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-purple-500/60 text-xs text-slate-300 hover:text-white transition-colors cursor-pointer"
            >
              <Hash className="w-3.5 h-3.5 text-purple-400" />
              <span>Hashtags</span>
            </button>
            <button
              type="button"
              onClick={() => onScrollTo('caption-generator')}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-pink-500/60 text-xs text-slate-300 hover:text-white transition-colors cursor-pointer"
            >
              <MessageSquare className="w-3.5 h-3.5 text-pink-400" />
              <span>Captions (8 Tones)</span>
            </button>
            <button
              type="button"
              onClick={() => onScrollTo('description-generator')}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-indigo-500/60 text-xs text-slate-300 hover:text-white transition-colors cursor-pointer"
            >
              <span>Descriptions</span>
            </button>
            <button
              type="button"
              onClick={() => onScrollTo('tag-generator')}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-cyan-500/60 text-xs text-slate-300 hover:text-white transition-colors cursor-pointer"
            >
              <span>SEO Tags</span>
            </button>
            <button
              type="button"
              onClick={() => onScrollTo('bio-generator')}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-emerald-500/60 text-xs text-slate-300 hover:text-white transition-colors cursor-pointer"
            >
              <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Bio (150 Chars)</span>
            </button>
            <button
              type="button"
              onClick={() => onScrollTo('reels-captions')}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-rose-500/60 text-xs text-slate-300 hover:text-white transition-colors cursor-pointer"
            >
              <Video className="w-3.5 h-3.5 text-rose-400" />
              <span>Reels Hooks</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
