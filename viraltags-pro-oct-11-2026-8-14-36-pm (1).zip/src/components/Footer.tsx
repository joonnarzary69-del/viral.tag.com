import React from 'react';
import { Sparkles } from 'lucide-react';

interface FooterProps {
  onOpenAbout: () => void;
  onOpenContact: () => void;
  onOpenPrivacy: () => void;
  onOpenTerms: () => void;
  onOpenDeploy: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onOpenAbout,
  onOpenContact,
  onOpenPrivacy,
  onOpenTerms,
  onOpenDeploy,
}) => {
  return (
    <footer className="mt-20 border-t border-slate-800/80 bg-[#07070c] py-12 text-slate-400 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 pb-8 border-b border-slate-800/60">
          {/* Brand */}
          <div className="flex flex-col items-center md:items-start text-center md:text-left">
            <div className="flex items-center gap-2 mb-1.5">
              <div className="w-6 h-6 rounded-md bg-gradient-to-tr from-purple-600 to-pink-500 flex items-center justify-center">
                <Sparkles className="w-3.5 h-3.5 text-white" />
              </div>
              <span className="text-base font-bold text-white tracking-tight">
                ViralTags Pro
              </span>
            </div>
            <p className="text-slate-400 text-xs">
              Create Better Content. Discover Better Hashtags.
            </p>
          </div>

          {/* Links */}
          <nav aria-label="Footer Navigation" className="flex flex-wrap items-center justify-center gap-6 text-xs text-slate-300">
            <button
              type="button"
              onClick={onOpenAbout}
              className="hover:text-purple-300 transition-colors cursor-pointer"
            >
              About
            </button>
            <button
              type="button"
              onClick={onOpenContact}
              className="hover:text-purple-300 transition-colors cursor-pointer"
            >
              Contact
            </button>
            <button
              type="button"
              onClick={onOpenPrivacy}
              className="hover:text-purple-300 transition-colors cursor-pointer"
            >
              Privacy Policy
            </button>
            <button
              type="button"
              onClick={onOpenTerms}
              className="hover:text-purple-300 transition-colors cursor-pointer"
            >
              Terms &amp; Conditions
            </button>
            <button
              type="button"
              onClick={onOpenDeploy}
              className="hover:text-pink-300 text-purple-400 transition-colors cursor-pointer font-medium"
            >
              Free Hosting Guide
            </button>
          </nav>
        </div>

        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-400 text-center sm:text-left">
          <p>
            &copy; {new Date().getFullYear()} ViralTags Pro. Independent creator utility. Not affiliated with Instagram or Meta Platforms, Inc.
          </p>
          <p>
            Crafted with React, TypeScript &amp; Tailwind CSS · Free &amp; Open Web Utility
          </p>
        </div>
      </div>
    </footer>
  );
};
