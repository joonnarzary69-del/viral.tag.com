import { Language } from './categories';

export type DescriptionLength = 'Short' | 'Medium' | 'Long';

export interface GeneratedDescription {
  headline: string;
  body: string;
  cta: string;
  suggestedTags: string[];
  fullText: string;
}

export const CTA_OPTIONS: { id: string; label: string; text: Record<Language, string> }[] = [
  {
    id: 'save',
    label: 'Save for later',
    text: {
      English: '📌 Save this post so you don’t lose it later!',
      Hindi: '📌 इस पोस्ट को सेव कर लें ताकि बाद में काम आए!',
      Assamese: '📌 পিছত যাতে হেৰাই নাযায়, এই পোষ্টটো Save কৰি ৰাখক!',
    },
  },
  {
    id: 'share',
    label: 'Share with friends',
    text: {
      English: '↗️ Share this with someone who really needs to see it today.',
      Hindi: '↗️ अपने उस दोस्त को शेयर करें जिसे आज इसकी सबसे ज़्यादा ज़रूरत है।',
      Assamese: '↗️ আপোনাৰ সেইজন বন্ধুলৈ Share কৰক যাৰ আজি এইটো জনাৰ প্ৰয়োজন আছে।',
    },
  },
  {
    id: 'comment',
    label: 'Comment thoughts',
    text: {
      English: '💬 What are your thoughts on this? Drop a comment below!',
      Hindi: '💬 आपकी इस बारे में क्या राय है? नीचे कमेंट बॉक्स में ज़रूर बताएं!',
      Assamese: '💬 এই বিষয়ত আপোনাৰ মতামত কি? তলৰ কমেন্ট বক্সত জনাওক!',
    },
  },
  {
    id: 'bio',
    label: 'Link in bio',
    text: {
      English: '🔗 Want the complete breakdown? Tap the link in my bio for more details.',
      Hindi: '🔗 पूरी जानकारी के लिए बायो (Bio) में दिए गए लिंक पर क्लिक करें।',
      Assamese: '🔗 বিতং তথ্যৰ বাবে মোৰ Bio ত থকা লিংকটো চাব পাৰে।',
    },
  },
  {
    id: 'doubletap',
    label: 'Double tap if agree',
    text: {
      English: '❤️ Double tap if this resonates with you!',
      Hindi: '❤️ अगर आप इस बात से सहमत हैं तो लाइक (Double tap) ज़रूर करें!',
      Assamese: '❤️ যদি কথাষাৰ সঁচা যেন লাগে তেন্তে এটা Like (Double tap) কৰি উৎসাহ যোগাওক!',
    },
  },
];

export function generatePostDescription(
  topic: string,
  length: DescriptionLength,
  language: Language,
  selectedCtaId: string = 'save'
): GeneratedDescription {
  const cleanTopic = topic.trim() || 'Content Creation';
  const ctaObj = CTA_OPTIONS.find((c) => c.id === selectedCtaId) || CTA_OPTIONS[0];
  const ctaText = ctaObj.text[language] || ctaObj.text.English;

  let headline = '';
  let body = '';
  let tags: string[] = [];

  if (language === 'English') {
    tags = [`#${cleanTopic.replace(/\s+/g, '')}`, '#creatorlife', '#instagramtips', '#contentstrategy', '#dailyinsights'];
    if (length === 'Short') {
      headline = `✨ Quick take on ${cleanTopic}:`;
      body = `When you simplify your focus on ${cleanTopic}, everything starts falling into place. Consistency matters more than sporadic perfection. Show up, do the work, and let compounding do the rest.`;
    } else if (length === 'Medium') {
      headline = `💡 The real secret behind ${cleanTopic} nobody talks about:`;
      body = `Most people overcomplicate ${cleanTopic} by chasing shortcuts, while true mastery comes from executing the fundamentals day after day.\n\nHere are 3 quick rules that changed the game:\n1. Start before you feel completely ready.\n2. Iterate quickly based on honest feedback rather than assumptions.\n3. Protect your focus from unnecessary daily distractions.\n\nKeep building, stay patient, and enjoy the craft.`;
    } else {
      headline = `🚀 Deep Dive: Everything you need to understand about ${cleanTopic}`;
      body = `If you have been struggling to make real progress with ${cleanTopic}, take a breath. You are not behind; you are just in the building phase.\n\nHere is what I wish someone told me before starting:\n\n• Clarity follows action, not overthinking. You cannot optimize zero output.\n• Build systems instead of relying solely on fleeting bursts of motivation.\n• Small daily habits compound into massive quarterly breakthroughs.\n• Celebrate the small wins that happen behind closed doors.\n\nRemember: Rome wasn't built in a day, but bricks were laid every single hour. Keep showing up for ${cleanTopic}.`;
    }
  } else if (language === 'Hindi') {
    tags = [`#${cleanTopic.replace(/\s+/g, '')}`, '#हिंदीकंटेंट', '#प्रेरणा', '#भारतक्रिएटर्स', '#विचार'];
    if (length === 'Short') {
      headline = `✨ ${cleanTopic} के बारे में एक ज़रूरी बात:`;
      body = `${cleanTopic} में सफलता पाने का कोई शॉर्टकट नहीं है। जब आप रोज़ाना थोड़ी-थोड़ी मेहनत करते हैं, तो नतीजे अपने आप दिखने लगते हैं। खुद पर विश्वास रखें और आगे बढ़ते रहें।`;
    } else if (length === 'Medium') {
      headline = `💡 ${cleanTopic} को लेकर सबसे बड़ी सच्चाई जो आपको समझनी चाहिए:`;
      body = `अक्सर हम ${cleanTopic} को बहुत मुश्किल समझ लेते हैं, जबकि असल खेल सिर्फ़ निरंतरता (Consistency) का है।\n\nये 3 बातें हमेशा याद रखें:\n1. सही समय का इंतज़ार मत करें, शुरुआत आज से करें।\n2. गलतियों से सीखें, उनसे डर कर रुकें नहीं।\n3. अपने काम में ईमानदारी और नयापन बनाए रखें।\n\nसफलता समय माँगती है, बस अपनी मेहनत पर अडिग रहें।`;
    } else {
      headline = `🚀 विस्तृत जानकारी: ${cleanTopic} में अपनी अलग पहचान कैसे बनाएं?`;
      body = `यदि आप ${cleanTopic} के सफर में मुश्किलों का सामना कर रहे हैं, तो याद रखें कि हर बड़ा मुकाम संघर्ष से होकर ही गुज़रता है।\n\nकुछ अनमोल सबक जो आपकी राह आसान करेंगे:\n\n• सोच बड़ी रखें लेकिन शुरुआत छोटे-छोटे कदमों से करें।\n• जब तक आप खुद पर विश्वास नहीं करेंगे, दुनिया आप पर यकीन नहीं करेगी।\n• तुलना करना बंद करें; हर किसी की अपनी अलग टाइमलाइन होती है।\n• ज्ञान और कौशल को रोज़ाना 1% बेहतर बनाने का नियम अपनाएं।\n\nमेहनत का कोई विकल्प नहीं होता, ${cleanTopic} में आपकी लगन ही आपको शिखर तक ले जाएगी।`;
    }
  } else {
    // Assamese
    tags = [`#${cleanTopic.replace(/\s+/g, '')}`, '#অসমীয়াকন্টেন্ট', '#অসমীয়াভাৱনা', '#জ্ঞানৰপোহৰ', '#নতুনচিন্তা'];
    if (length === 'Short') {
      headline = `✨ ${cleanTopic} সন্দৰ্ভত এটি প্ৰয়োজনীয় কথা:`;
      body = `${cleanTopic} ত সফলতা পাবলৈ হ'লে ধৈৰ্য্য আৰু একাগ্ৰতাৰ অতি প্ৰয়োজন। এদিনতে সকলো সলনি নহয়, কিন্তু প্ৰতিদিনে কৰা অলপ পৰিশ্ৰমে এদিন ডাঙৰ পৰিৱৰ্তন আনিব পাৰে।`;
    } else if (length === 'Medium') {
      headline = `💡 ${cleanTopic} ৰ আঁৰৰ সেই বিশেষ সত্যটো যিটো জনা দৰকাৰ:`;
      body = `আমি প্ৰায়ে ${cleanTopic} ক বৰ জটিল বুলি ভাবোঁ, কিন্তু বাস্তৱত ই কেৱল অভ্যাস আৰু শিকাৰ হে কথা।\n\nমনত ৰাখিবলগীয়া ৩টা মূল নীতি:\n১. নিখুঁত সময়লৈ অপেক্ষা নকৰি আজিৰ পৰাই আৰম্ভ কৰক।\n২. ভুলবোৰক শুধৰণিৰ সুযোগ হিচাপে গ্ৰহণ কৰক।\n৩. আনৰ সমালোচনাৰ ভয়ত নিজৰ সপোন ত্যাগ নকৰিব।\n\nনিজৰ পথত অবিচল থাকক, সফলতা নিশ্চিতভাৱে আপোনাৰ কাষ চাপিব।`;
    } else {
      headline = `🚀 বিতংভাৱে: ${cleanTopic} ৰ জৰিয়তে নিজৰ জীৱনক নতুন গতি দিয়ক`;
      body = `যদি আপুনি ${cleanTopic} ৰ যাত্ৰাত কিছু বাধাৰ সন্মুখীন হৈছে, তেন্তে হতাশ নহ'ব। প্ৰতিটো সংগ্ৰামেই একো একোটা নতুন পাঠ শিকাই যায়।\n\nমনত ৰাখিবলগীয়া কেইটামান গুৰুত্বপূৰ্ণ কথা:\n\n• ডাঙৰ সফলতাৰ বাবে দৈনিক সৰু সৰু পদক্ষেপ লোৱাটো জৰুৰী।\n• আনৰ লগত তুলনা কৰাৰ পৰিৱৰ্তে কালিৰ নিজৰ তুলনাত আজি কিমান উন্নত হ'ল তালৈ লক্ষ্য ৰাখক।\n• পৰিশ্ৰম আৰু সততা থাকিলে যিকোনো কঠিন কামেই সহজ হৈ পৰে।\n• মনৰ ভয়বোৰক সাহসত পৰিণত কৰাই হৈছে প্ৰকৃত বিজয়ীৰ লক্ষণ।\n\nআপোনাৰ নিষ্ঠাই ${cleanTopic} ত এক অনন্য পৰিচয় আনি দিব। যাত্ৰাটো উপভোগ কৰক!`;
    }
  }

  const fullText = `${headline}\n\n${body}\n\n${ctaText}\n\n${tags.join(' ')}`;

  return {
    headline,
    body,
    cta: ctaText,
    suggestedTags: tags,
    fullText,
  };
}
