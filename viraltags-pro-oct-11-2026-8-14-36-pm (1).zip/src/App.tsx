/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Navigation } from './components/Navigation';
import { HeroSection } from './components/HeroSection';
import { ToolCardsGrid } from './components/ToolCardsGrid';
import { HashtagGeneratorSection } from './components/HashtagGeneratorSection';
import { CaptionGeneratorSection } from './components/CaptionGeneratorSection';
import { DescriptionGeneratorSection } from './components/DescriptionGeneratorSection';
import { TagGeneratorSection } from './components/TagGeneratorSection';
import { BioGeneratorSection } from './components/BioGeneratorSection';
import { ReelsCaptionSection } from './components/ReelsCaptionSection';
import { AlgorithmGuide } from './components/AlgorithmGuide';
import { AdSenseSlot } from './components/AdSenseSlot';
import { Footer } from './components/Footer';
import { AboutModal } from './components/AboutModal';
import { ContactModal } from './components/ContactModal';
import { PrivacyModal } from './components/PrivacyModal';
import { TermsModal } from './components/TermsModal';
import { DeployGuideModal } from './components/DeployGuideModal';
import { Toast } from './components/Toast';

export default function App() {
  // Modal states
  const [aboutOpen, setAboutOpen] = useState(false);
  const [contactOpen, setContactOpen] = useState(false);
  const [privacyOpen, setPrivacyOpen] = useState(false);
  const [termsOpen, setTermsOpen] = useState(false);
  const [deployOpen, setDeployOpen] = useState(false);

  // Notification state
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((current) => (current === msg ? null : current));
    }, 2400);
  };

  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#09090f] text-slate-100 flex flex-col selection:bg-purple-600 selection:text-white">
      {/* Top Navigation */}
      <Navigation
        onOpenAbout={() => setAboutOpen(true)}
        onOpenContact={() => setContactOpen(true)}
      />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8">
        {/* 1. Hero Section */}
        <HeroSection
          onScrollTo={scrollTo}
          onOpenAbout={() => setAboutOpen(true)}
        />

        {/* AdSense Top Leaderboard */}
        <AdSenseSlot
          format="leaderboard"
          slotName="Homepage Header Leaderboard"
          className="my-8"
        />

        {/* 2. Overview of all tools */}
        <ToolCardsGrid onSelectTool={scrollTo} />

        {/* 3. Instagram Hashtag Generator */}
        <HashtagGeneratorSection onNotify={showToast} />

        {/* 4. Viral Caption Generator */}
        <CaptionGeneratorSection onNotify={showToast} />

        {/* In-feed AdSense Unit */}
        <AdSenseSlot
          format="in-feed"
          slotName="Mid-Content Native In-Feed"
          className="my-10"
        />

        {/* 5. Instagram Description Generator */}
        <DescriptionGeneratorSection onNotify={showToast} />

        {/* 6. Instagram Tag & Keyword Generator */}
        <TagGeneratorSection onNotify={showToast} />

        {/* 7. Instagram Bio Generator */}
        <BioGeneratorSection onNotify={showToast} />

        {/* 8. Dedicated Reels Caption Generator */}
        <ReelsCaptionSection onNotify={showToast} />

        {/* 9. Original Educational Guide on Instagram Algorithm 2026 */}
        <AlgorithmGuide />

        {/* Pre-footer AdSense Leaderboard */}
        <AdSenseSlot
          format="leaderboard"
          slotName="Pre-Footer Leaderboard"
          className="my-12"
        />
      </main>

      {/* Footer */}
      <Footer
        onOpenAbout={() => setAboutOpen(true)}
        onOpenContact={() => setContactOpen(true)}
        onOpenPrivacy={() => setPrivacyOpen(true)}
        onOpenTerms={() => setTermsOpen(true)}
        onOpenDeploy={() => setDeployOpen(true)}
      />

      {/* Interactive Modals */}
      <AboutModal isOpen={aboutOpen} onClose={() => setAboutOpen(false)} />
      <ContactModal isOpen={contactOpen} onClose={() => setContactOpen(false)} />
      <PrivacyModal isOpen={privacyOpen} onClose={() => setPrivacyOpen(false)} />
      <TermsModal isOpen={termsOpen} onClose={() => setTermsOpen(false)} />
      <DeployGuideModal isOpen={deployOpen} onClose={() => setDeployOpen(false)} />

      {/* Toast Feedback */}
      <Toast message={toastMessage} onClose={() => setToastMessage(null)} />
    </div>
  );
}
